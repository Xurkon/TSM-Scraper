# Changelog

## [v3.4.14] - 2025-12-18

### Bug Fixes

- **Fixed Critical TSM 2.8 Visibility Bug (Ascension)**: Resolved issues where imported groups/items would write to SavedVariables but not appear in the TSM sidebar.
  - Fixed destructive `cleanup_ui_state` that was wiping newly added `groupTreeStatus` entries.
  - Added support for missing profile keys (`groupTreeCollapsedStatus`, `isBankui`, `moveImportedItems`) required for structural integrity.
  - Updated default group operation to `"AlwaysUndercut"` for better out-of-the-box functionality.
  - Improved profile replenishment logic for fresh/reset TSM profiles.

---

## [v3.4.13] - 2025-12-18

### Bug Fixes

- **Fixed TSM 2.8 Group Recognition (Ascension)**: Added support for `groupTreeStatus` table updates.
  - Groups now correctly show up as expanded/visible in the TSM sidebar.
  - Proper formatting for expansion state keys: `["1 {FullPath}"]` and `["1 {Parent} {FullPath}"]`.
- **Improved Data Integrity**: Verified that all groups contain the required blank operation placeholders and items are correctly assigned.

---

## [v3.4.12] - 2025-12-18

### Bug Fixes

- **Fixed TSM Group Existence Check**: Resolved bug where groups with backticks (e.g. `Transmog`Axes`) were not correctly detected.
- **Fixed SavedVariables Corruption**: Resolved issues causing blank lines and malformed entries in `TradeSkillMaster.lua`.
- **Improved GUI Feedback**: Logs now accurately report if a group exists even if it's collapsed in the TSM sidebar.

---

## [v3.4.11] - 2025-12-18

### Bug Fixes

- **Fixed TSM 2.8 Item Grouping (Ascension)**: Items now correctly assign to groups within the `["items"]` table
  - Resolved discrepancy where items were written as siblings to groups (TSM 2.8 requires them inside `["items"]`)
  - Improved `_ensure_items_table_exists_ascension` to correctly position the table within the `Default` profile
  - Fixed indentation for item entries (4 tabs) and the table itself (3 tabs)
  - Verified fix with TSM 2.8 `FULLTradeSkillMaster.lua` structure

---
... (rest of the file preserved) ...
